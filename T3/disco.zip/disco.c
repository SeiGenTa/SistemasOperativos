#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>

#include "pss.h"
#include "disco.h"

typedef struct{
    char* name;
    char* namePartner;
    pthread_cond_t cond;
} Person;

Person *InitPerson(char *name){
    Person *p = malloc(sizeof(Person));
    p->name = name;
    p->namePartner = NULL;
    pthread_cond_init(&p->cond,NULL);
    return p;
}

//we create the rows
Queue *row_men;
Queue *row_women;

//we create a mutex
pthread_mutex_t t = PTHREAD_MUTEX_INITIALIZER;

void DiscoInit(void){
    row_men = makeQueue();
    row_women = makeQueue();
}

void DiscoDestroy(void) {
    destroyQueue(row_men);
    destroyQueue(row_women);
}

char *dama(char *nom) {
    Person* me =InitPerson(nom);

    char* nameParner = NULL;

    pthread_mutex_lock(&t);
    if (emptyQueue(row_men)){
        put(row_women,me);

        while (me->namePartner == NULL){
            pthread_cond_wait(&(me->cond),&t);
        }
        pthread_mutex_unlock(&t);
        nameParner = me->namePartner;
    }
    else{
        Person* parner = get(row_men);
        nameParner = parner->name;
        parner->namePartner = nom;
        pthread_cond_broadcast(&parner->cond);
        pthread_mutex_unlock(&t);
    }
    free(me);
    return nameParner;
}

char *varon(char *nom) {
    Person* me =InitPerson(nom);

    char* nameParner = NULL;

    pthread_mutex_lock(&t);

    if (emptyQueue(row_women)){
        put(row_men,me);
        while (me->namePartner == NULL){
            pthread_cond_wait(&(me->cond),&t);
        }
        pthread_mutex_unlock(&t);
        nameParner = me->namePartner;

    }
    else{
        Person* parner = get(row_women);
        nameParner = parner->name;
        parner->namePartner = nom;
        pthread_cond_broadcast(&parner->cond);
        pthread_mutex_unlock(&t);
        }
    free(me);
    return nameParner;
    }
